<?php
/**
 * Created by PhpStorm.
 * User: tagdiv
 * Date: 10.05.2019
 * Time: 12:29
 */

do_action( 'tdc_sidebar' );